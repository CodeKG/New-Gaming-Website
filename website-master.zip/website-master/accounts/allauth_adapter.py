"""Custom allauth adapters for Lutris"""

import logging

from allauth.account.adapter import DefaultAccountAdapter
from allauth.core.exceptions import ImmediateHttpResponse
from allauth.socialaccount.adapter import DefaultSocialAccountAdapter
from django.contrib.sites.shortcuts import get_current_site
from django.db import IntegrityError
from django.shortcuts import render

logger = logging.getLogger(__name__)


class LutrisAccountAdapter(DefaultAccountAdapter):
    """Prevent allauth from handling signup — Lutris has its own registration."""

    def is_open_for_signup(self, request):
        return False


class LutrisSocialAccountAdapter(DefaultSocialAccountAdapter):
    """Handle social login integration for Steam, Discord, Google."""

    def is_open_for_signup(self, request, sociallogin):
        """Open to everyone except addresses that were banned for spam"""
        from accounts.models import BannedAccount

        for email_address in sociallogin.email_addresses:
            if BannedAccount.is_email_banned(email_address.email):
                logger.info("Refused social signup for banned email")
                return False
        return True

    def pre_social_login(self, request, sociallogin):
        """Connect social account to existing user if possible."""
        if sociallogin.is_existing:
            return

        user = None

        # For Steam, match by steamid field
        if sociallogin.account.provider == "steam":
            from accounts.models import User

            try:
                user = User.objects.get(steamid=sociallogin.account.uid)
            except User.DoesNotExist:
                pass
            except User.MultipleObjectsReturned:
                logger.warning(
                    "Multiple users with steamid %s, skipping auto-connect",
                    sociallogin.account.uid,
                )

        # For providers with email, match by email
        if sociallogin.account.provider in ("discord", "google"):
            email = sociallogin.email_addresses[0].email if sociallogin.email_addresses else None
            if email:
                from accounts.models import User

                try:
                    user = User.objects.get(email=email)
                except User.DoesNotExist:
                    pass
                except User.MultipleObjectsReturned:
                    logger.warning(
                        "Multiple users with email %s, skipping auto-connect",
                        email,
                    )

        if user:
            sociallogin.connect(request, user)

    def on_authentication_error(
        self, request, provider_id, error=None, exception=None, extra_context=None
    ):
        from allauth.socialaccount.providers.base import AuthError

        if error == AuthError.CANCELLED:
            logger.info("Social login cancelled for %s", provider_id)
        else:
            logger.warning(
                "Social login error for %s: error=%s exception=%s",
                provider_id,
                error,
                exception,
                exc_info=exception,
            )
        return super().on_authentication_error(
            request, provider_id, error=error, exception=exception, extra_context=extra_context
        )

    def save_user(self, request, sociallogin, form=None):
        """After saving social user, set the steamid field if Steam."""
        try:
            user = super().save_user(request, sociallogin, form)
        except IntegrityError:
            # Allauth's form-level username uniqueness check can be raced past
            # by a concurrent signup or a double-submitted form, leaving the
            # unique-constraint violation as the only safety net. Re-render the
            # signup form with a friendly error instead of returning a 500.
            from accounts.models import User

            username = sociallogin.user.username
            if (
                form is None
                or not username
                or not User.objects.filter(username__iexact=username).exists()
            ):
                raise
            form.add_error(
                "username",
                "A user with that username already exists. Please choose another.",
            )
            raise ImmediateHttpResponse(
                render(
                    request,
                    "socialaccount/signup.html",
                    {
                        "form": form,
                        "account": sociallogin.account,
                        "site": get_current_site(request),
                    },
                )
            )
        if sociallogin.account.provider == "steam":
            user.steamid = sociallogin.account.uid
            user.save(update_fields=["steamid"])
        return user
