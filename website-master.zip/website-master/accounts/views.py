"""Module for user account views"""

# pylint: disable=too-many-ancestors,raise-missing-from
import json
import logging
import time
from collections import defaultdict
from datetime import datetime, timezone

from axes.helpers import get_client_ip_address
from django.conf import settings
from django.contrib import messages
from django.contrib.auth import logout, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.views import (
    LoginView,
    LogoutView,
    PasswordChangeDoneView,
    PasswordChangeView,
    PasswordResetConfirmView,
    PasswordResetDoneView,
    PasswordResetView,
)
from django.http import (
    Http404,
    HttpResponse,
    HttpResponseBadRequest,
    HttpResponseRedirect,
)
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse, reverse_lazy
from django.views.generic import CreateView, ListView, UpdateView
from django.views.generic.edit import FormView
from rest_framework import generics
from rest_framework.authtoken.models import Token
from rest_framework.permissions import IsAuthenticated

from games import models

from . import forms, serializers, sso, tasks
from .models import EmailConfirmationToken, User

LOGGER = logging.getLogger(__name__)


def sanitize_lastplayed(value):
    """Sanitize lastplayed timestamp, returning 0 for invalid values."""
    value = int(value or 0)
    if value > int(time.time()) or value > 2147483647:
        return 0
    return value


class LutrisRegisterView(CreateView):
    """Account registration view"""

    form_class = forms.RegistrationForm
    template_name = "accounts/register.html"
    success_url = reverse_lazy("homepage")

    def form_valid(self, form):
        """Keep the signup address: it is what links sockpuppet accounts"""
        # Set before the insert rather than saving a second time: the form hands
        # back an unsaved user when the username is taken, and forcing an update
        # on it raises "Cannot force an update in save() with no primary key".
        form.instance.signup_ip = get_client_ip_address(self.request)
        response = super().form_valid(form)
        if self.object.pk is None:
            # RegistrationForm.save() swallows the IntegrityError from a username
            # taken between validation and insert. No account exists, so say so
            # instead of redirecting to the success page.
            form.add_error("username", self.form_class.error_messages["duplicate_username"])
            return self.form_invalid(form)
        return response


class LutrisLoginView(LoginView):
    """Sign in view"""

    template_name = "accounts/login.html"
    authentication_form = AuthenticationForm


class LutrisLogoutView(LogoutView):
    """Sign out view"""

    next_page = "/"

    def dispatch(self, request, *args, **kwargs):
        messages.success(request, "You are now logged out of Lutris.")
        return super().dispatch(request, *args, **kwargs)


class LutrisPasswordResetView(PasswordResetView):
    """View to reset a user's password"""

    template_name = "accounts/password_reset.html"
    form_class = forms.LutrisPasswordResetForm


class LutrisPasswordResetDoneView(PasswordResetDoneView):
    """Tell the user an email has been sent with a password reset link"""

    template_name = "accounts/password_reset_done.html"


class LutrisPasswordChangeView(PasswordChangeView):
    """View confirming the password reset is sent"""

    template_name = "accounts/password_change.html"


class LutrisPasswordChangeDoneView(PasswordChangeDoneView):
    """View confirming the password was changed"""

    template_name = "accounts/password_change_done.html"


class LutrisPasswordResetConfirmView(PasswordResetConfirmView):
    """View where the user confirms the password reset"""

    template_name = "accounts/password_reset_confirm.html"
    success_url = reverse_lazy("login")

    def form_valid(self, form):
        messages.success(self.request, "Your password has been updated.")
        return super().form_valid(form)


class LutrisSetPasswordView(LoginRequiredMixin, FormView):
    """Let a logged-in social-auth user set their initial password.

    Users created via Discord/Google/Steam have set_unusable_password() and
    therefore can't sign in to the desktop client, which only supports
    username + password auth. PasswordChangeView won't help because it
    requires the old password.
    """

    template_name = "accounts/password_set.html"
    form_class = forms.SetUsernameAndPasswordForm
    success_url = reverse_lazy("profile")

    def dispatch(self, request, *args, **kwargs):
        if request.user.is_authenticated and request.user.has_usable_password():
            return redirect("password_change")
        return super().dispatch(request, *args, **kwargs)

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs["user"] = self.request.user
        return kwargs

    def form_valid(self, form):
        user = form.save()
        update_session_auth_hash(self.request, user)
        messages.success(
            self.request,
            f"Password set. Sign in to the Lutris desktop client with username "
            f"'{user.username}' and your new password.",
        )
        return super().form_valid(form)


def clear_auth_token(request):
    """Delete the REST API token for the currently logged in user"""
    if not request.user.is_authenticated:
        # Anonymous users fuck off
        return redirect("/")
    try:
        token = Token.objects.get(user=request.user)
    except Token.DoesNotExist:
        raise Http404
    token.delete()
    messages.info(
        request,
        "You authentication token has been cleared. "
        "Please sign-in in Lutris again to generate a new one.",
    )
    return redirect(reverse("user_account", kwargs={"username": request.user.username}))


@login_required
def profile(request):
    """Redirect to user account
    Takes the username from the request, allows to have a unique URL for all profiles.
    """
    return HttpResponseRedirect(reverse("user_account", args=(request.user.username,)))


def user_account(request, username):
    """Profile view"""
    if request.user.username != username:
        raise Http404
    return render(
        request,
        "accounts/profile.html",
        {"user": request.user, "profile_page": "profile"},
    )


@login_required
def user_submissions(request):
    """Lists a user game submissions"""
    pending_submissions = models.GameSubmission.objects.filter(
        user=request.user, accepted_at__isnull=True
    )
    accepted_submissions = models.GameSubmission.objects.filter(
        user=request.user, accepted_at__isnull=False
    )
    return render(
        request,
        "accounts/game_submissions.html",
        {
            "pending_submissions": pending_submissions,
            "accepted_submissions": accepted_submissions,
        },
    )


@login_required
def user_send_confirmation(request):
    """Send an email with a confirmation link"""
    user = request.user
    if user.email_confirmed:
        messages.info(request, "Your email has already been confirmed.")
        return HttpResponseRedirect(reverse("user_account", args=(user.username,)))
    token = EmailConfirmationToken(email=user.email)
    token.create_token()
    token.save()
    token.send(request)
    messages.info(
        request,
        "An email with a confirmation link has been sent to the specified "
        "address. Click the link to confirm your email address.",
    )
    return HttpResponseRedirect(reverse("user_account", args=(user.username,)))


def user_require_confirmation(request):
    """Display an error message that the resource is reserved for confirmed
    accounts only.
    """
    if request.user.is_authenticated:
        messages.error(
            request,
            "The page you have requested requires that you have confirmed your email address.",
        )
        return redirect(reverse("user_account", args=(request.user.username,)))
    login_url = settings.LOGIN_URL
    if "next" in request.GET:
        login_url += "?next=" + request.GET["next"]
    return redirect(login_url)


def user_email_confirm(request):
    """Confirm an user's account

    This is the view pointed by the link in the confirmation email
    """
    token = request.GET.get("token")
    confirmation_token = get_object_or_404(EmailConfirmationToken, token=token)
    if confirmation_token.is_valid():
        confirmation_token.confirm_user()
        confirmation_token.delete()
    return render(
        request,
        "accounts/confirmation_received.html",
        {"confirmation_token": confirmation_token},
    )


class ProfileUpdateView(LoginRequiredMixin, UpdateView):
    """Edit the user's profile info"""

    template_name = "accounts/profile_edit.html"
    form_class = forms.ProfileForm
    success_url = reverse_lazy("profile")

    def get_object(self, queryset=None):
        return self.request.user

    def get_context_data(self, *args, **kwargs):  # pylint: disable=arguments-differ
        context = super().get_context_data(*args, **kwargs)
        context["profile_page"] = "edit"
        return context


@login_required
def profile_delete(request, username):
    """Deactivate a user account"""
    user = get_object_or_404(User, username=username)
    if user != request.user:
        raise Http404
    form = forms.ProfileDeleteForm(request.POST or None)
    if form.is_valid():
        logout(request)
        user.deactivate()
        messages.success(request, "Your account is now deleted")
        return redirect(reverse("homepage"))
    return render(request, "accounts/profile_delete.html", {"form": form})


@login_required
def steam_disconnect(request):
    """Clears the Steam ID and disconnects the social account"""
    from allauth.socialaccount.models import SocialAccount

    SocialAccount.objects.filter(user=request.user, provider="steam").delete()
    request.user.steamid = ""
    request.user.save()
    return redirect(reverse("profile"))


class LibraryList(ListView):  # pylint: disable=too-many-ancestors
    """Access the user's game library"""

    template_name = "accounts/library_list.html"
    context_object_name = "games"
    ordering = "name"
    profile_page = "library"
    paginate_by = 60
    allowed_sort_fields = {
        "name",
        "-name",
        "created_at",
        "-created_at",
        "updated_at",
        "-updated_at",
    }

    def get_user(self):
        """Return a user object from the username url segment"""
        try:
            user = User.objects.get(username=self.kwargs["username"])
        except User.DoesNotExist:
            try:
                user = User.objects.get(username__iexact=self.kwargs["username"])
            except User.DoesNotExist:
                raise Http404
            except User.MultipleObjectsReturned:
                raise Http404
        return user

    def get_sort_field(self):
        """Return validated sort field or default ordering"""
        sort = self.request.GET.get("sort")
        if sort and sort in self.allowed_sort_fields:
            return sort
        return self.ordering

    def get_queryset(self):
        """Return all games in library, optionally filter them"""
        queryset = models.LibraryGame.objects.filter(gamelibrary__user=self.get_user())
        search_query = self.request.GET.get("q", "")
        # Sanitize: remove NULL bytes and limit length
        search_query = search_query.replace("\x00", "")[:200]
        if search_query:
            queryset = queryset.filter(name__icontains=search_query)
        return queryset.order_by(self.get_sort_field())

    def get_context_data(self, *, object_list=None, **kwargs):  # pylint: disable=unused-argument
        """Display the user's library"""
        context = super().get_context_data(object_list=object_list, **kwargs)
        user = self.get_user()
        if self.request.user != user:
            # Libraries are currently private. This will change once public
            # profiles are implemented
            raise Http404
        context["user"] = user
        context["profile_page"] = self.profile_page
        context["q"] = self.request.GET.get("q", "")
        context["sort"] = self.request.GET.get("sort", "")
        context["order_by"] = self.request.GET.get("sort", "")
        return context


class SubmissionList(LibraryList):  # pylint: disable=too-many-ancestors
    """List all user submissions"""

    template_name = "accounts/submission_list.html"
    context_object_name = "submissions"
    ordering = "-created_at"
    profile_page = "submissions"
    allowed_sort_fields = {"name", "-name", "created_at", "-created_at"}

    def get_queryset(self):
        """Return all submitted games"""
        queryset = models.GameSubmission.objects.filter(user=self.get_user())
        search_query = self.request.GET.get("q", "").replace("\x00", "")[:200]
        if search_query:
            queryset = queryset.filter(game__name__icontains=search_query)
        return queryset.order_by(self.get_sort_field())


INSTALLER_ALLOWED_SORT_FIELDS = {
    "name",
    "-name",
    "created_at",
    "-created_at",
    "updated_at",
    "-updated_at",
}


@login_required
def installer_list(request, username):
    """List all private installers"""
    if username != request.user.username:
        raise Http404

    installers = models.InstallerDraft.objects.filter(user=request.user)
    search_query = request.GET.get("q", "").replace("\x00", "")[:200]
    if search_query:
        installers = installers.filter(game__name__icontains=search_query)
    sort = request.GET.get("sort")
    sort_field = sort if sort in INSTALLER_ALLOWED_SORT_FIELDS else "-created_at"
    installers = installers.order_by(sort_field)
    return render(
        request,
        "accounts/installer_list.html",
        {"user": request.user, "profile_page": "installers", "installers": installers},
    )


@login_required
def library_add(request, slug):
    """Add a game to the user's library"""
    library = models.GameLibrary.objects.get(user=request.user)
    game = get_object_or_404(models.Game, slug=slug)
    models.LibraryGame.objects.create(
        name=game.name,
        slug=game.slug,
        game=game,
        gamelibrary=library,
    )
    return redirect(game.get_absolute_url())


@login_required
def library_remove(request, pk):
    """Remove a game from a user's library"""
    gamelibrary = models.GameLibrary.objects.get(user=request.user)
    library_game = get_object_or_404(models.LibraryGame, pk=pk)
    if library_game.gamelibrary != gamelibrary:
        response = HttpResponse("smartass")
        response.status_code = 418
        return response
    library_game.delete()
    redirect_url = request.META.get("HTTP_REFERER")
    if not redirect_url:
        redirect_url = reverse("library_list", kwargs={"username": request.user.username})
    return redirect(redirect_url)


@login_required
def library_steam_sync(request):
    """Launch a Steam library sync in the background"""
    user = request.user
    if not user.steamid:
        messages.error(
            request,
            "Your Steam account is not connected to Lutris. "
            "Please link your Steam account before syncing your library.",
        )
        return redirect(reverse("user_account", kwargs={"username": user.username}))
    LOGGER.info("Syncing contents of Steam library for user %s", user.username)
    tasks.sync_steam_library.delay(user.id)
    messages.success(request, "Your Steam library is being synced with your Lutris account")
    return redirect(reverse("library_list", kwargs={"username": user.username}))


@login_required
def discourse_sso(request):
    """View used to sign in a user to the Discourse forums"""
    if not request.user.email_confirmed:
        return HttpResponseBadRequest("You must confirm your email to use the forums")
    payload = request.GET.get("sso")
    signature = request.GET.get("sig")
    try:
        nonce = sso.validate(payload, signature, settings.DISCOURSE_SSO_SECRET)
    except RuntimeError as ex:
        return HttpResponseBadRequest(ex.args[0])

    url = sso.redirect_url(
        nonce,
        settings.DISCOURSE_SSO_SECRET,
        request.user.email,
        request.user.id,
        request.user.username,
    )
    return redirect(settings.DISCOURSE_URL + url)


class UserDetailView(generics.RetrieveAPIView):
    """Return the information for the currently logged in user"""

    permission_classes = [IsAuthenticated]
    serializer_class = serializers.UserSerializer
    queryset = User.objects.all()

    def get_object(self):
        return self.request.user


class GameLibraryAPIView(generics.ListCreateAPIView):
    """List a user's library"""

    permission_classes = [IsAuthenticated]
    serializer_class = serializers.LibrarySerializer
    pagination_class = None

    def get_queryset(self, ignore_since=False):
        queryset = (
            models.LibraryGame.objects.prefetch_related("game", "categories")
            .filter(gamelibrary__user=self.request.user)
            .order_by("game__slug")
        )
        since = self.request.GET.get("since")
        if ignore_since:
            since = None
        if since:
            dt = datetime.fromtimestamp(int(since), tz=timezone.utc)
            queryset = queryset.filter(updated_at__gte=dt)
        return queryset

    def is_empty_key(self, key):
        """Return true if runner, platform, service are empty"""
        return not key[1] and not key[2] and not key[3]

    def get_lutris_game(self, slug):
        if not slug:
            return None
        try:
            return models.Game.objects.get(slug=slug, change_for=None)
        except models.Game.DoesNotExist:
            pass
        games = list(
            models.Game.objects.filter(aliases__slug=slug, change_for=None)
            .distinct()
            .order_by("id")
        )
        if len(games) > 1:
            LOGGER.warning(
                "Alias slug '%s' matches multiple games: %s",
                slug,
                [g.id for g in games],
            )
        return games[0] if games else None

    @staticmethod
    def is_game_list(payload):
        """Whether a library payload is a list of games, each with a slug"""
        return isinstance(payload, list) and all(
            isinstance(game, dict) and "slug" in game for game in payload
        )

    def post(self, request, *args, **kwargs):
        if not self.is_game_list(request.data):
            LOGGER.warning("Rejected malformed library sync from %s", request.user.username)
            return HttpResponseBadRequest("Expected a list of games")
        client_library = defaultdict(list)
        library = models.GameLibrary.objects.get(user=request.user)
        for game in request.data:
            client_library[game["slug"]].append(game)
        stored_library = self.get_queryset(ignore_since=True)
        stored_categories = {
            c.name: c for c in models.LibraryCategory.objects.filter(gamelibrary=library)
        }
        updated_games = set()
        stats = {
            "user": request.user.username,
            "unchanged": 0,
            "updated": 0,
            "created": 0,
            "errors": 0,
        }

        def get_category(category_name):
            if not category_name:
                return None
            if category_name not in stored_categories:
                category = models.LibraryCategory.objects.create(
                    gamelibrary=library, name=category_name
                )
                stored_categories[category_name] = category
            else:
                category = stored_categories[category_name]
            return category

        for game in stored_library:
            if game.get_slug() in client_library:
                client_games = client_library[game.get_slug()]
                stored_key = (
                    game.get_slug(),
                    game.runner or "",
                    game.platform or "",
                    game.service or "",
                )
                for client_game in client_games:
                    client_key = (
                        client_game["slug"],
                        client_game["runner"] or "",
                        client_game["platform"] or "",
                        client_game["service"] or "",
                    )
                    if client_key == stored_key or self.is_empty_key(stored_key):
                        changed = False
                        if not game.game:
                            lutris_game = self.get_lutris_game(client_game["slug"])
                            if lutris_game:
                                game.game = lutris_game
                                changed = True
                        if game.name != client_game["name"]:
                            game.name = client_game["name"]
                            changed = True
                        if game.runner != client_game["runner"]:
                            game.runner = client_game["runner"]
                            changed = True
                        if game.platform != client_game["platform"]:
                            game.platform = client_game["platform"]
                            changed = True
                        client_lastplayed = sanitize_lastplayed(client_game["lastplayed"])
                        if not game.lastplayed or game.lastplayed < client_lastplayed:
                            if game.lastplayed != client_lastplayed:
                                game.lastplayed = client_lastplayed
                                changed = True
                        client_playtime = float(client_game["playtime"] or 0)
                        if not game.playtime or game.playtime < client_playtime:
                            if game.playtime != client_playtime:
                                game.playtime = client_playtime
                                changed = True
                        if game.service != client_game["service"]:
                            game.service = client_game["service"]
                            game.service_id = client_game["service_id"]
                            changed = True
                        for category_name in client_game.get("categories", []):
                            category = get_category(category_name)
                            if category and category not in game.categories.all():
                                game.categories.add(category)
                                changed = True

                        if changed:
                            game.save()
                            stats["updated"] += 1
                        else:
                            stats["unchanged"] += 1
                        stored_key = client_key
                        updated_games.add(stored_key)

        for slug in client_library:
            client_games = client_library[slug]
            for client_game in client_games:
                if (
                    "runner" not in client_game
                ):  # Skip invalid entries, I don't even know how there are created.
                    continue
                client_key = (
                    client_game["slug"],
                    client_game["runner"] or "",
                    client_game["platform"] or "",
                    client_game["service"] or "",
                )
                if client_key in updated_games:
                    continue

                game = self.get_lutris_game(client_game["slug"])
                library_game = models.LibraryGame.objects.create(
                    game=game,
                    name=client_game["name"],
                    slug=client_game["slug"],
                    gamelibrary=library,
                    playtime=client_game["playtime"] or 0,
                    runner=client_game["runner"],
                    platform=client_game["platform"],
                    service=client_game["service"],
                    lastplayed=sanitize_lastplayed(client_game["lastplayed"]),
                )
                for category_name in client_game.get("categories", []):
                    category = get_category(category_name)
                    if category:
                        library_game.categories.add(category)
                stats["created"] += 1
                LOGGER.info("Create new Library game %s", client_game)
        LOGGER.info(stats)
        return self.get(request)

    def delete_game(self, game):
        library_games = models.LibraryGame.objects.filter(
            gamelibrary__user=self.request.user, slug=game["slug"]
        )
        if len(library_games) == 1:
            return library_games[0].delete()

        if "lastplayed" not in game:
            # lastplayed is the only way to tell duplicate entries apart
            LOGGER.warning(
                "Not deleting %s for %s: %s entries match and no lastplayed was sent",
                game["slug"],
                self.request.user.username,
                len(library_games),
            )
            return [""]
        for library_game in library_games:
            if library_game.lastplayed == game["lastplayed"]:
                return library_game.delete()
        return [""]

    def delete(self, request):
        if not self.is_game_list(request.data):
            LOGGER.warning("Rejected malformed library delete from %s", request.user.username)
            return HttpResponseBadRequest("Expected a list of games")
        stats = {"delete_results": {}}
        for game in request.data:
            slug = game["slug"]
            if not slug:
                LOGGER.warning("No slug provided")
                return HttpResponseBadRequest("Missing slug")
            result = self.delete_game(game)
            stats["delete_results"][slug] = result[0]
        return HttpResponse(json.dumps(stats))
