"""DRF serializers for Game models"""

# pylint: disable=too-few-public-methods
import logging

from rest_framework import serializers

from accounts.serializers import UserSerializer
from games import antispam, models
from platforms.models import Platform
from providers.serializers import ProviderGameSerializer
from runners.models import Runner

LOGGER = logging.getLogger(__name__)


class PlatformSerializer(serializers.ModelSerializer):
    """Serializer for Platforms"""

    class Meta:
        """Model and field definitions"""

        model = Platform
        fields = ("name",)


class GenreSerializer(serializers.ModelSerializer):
    """Serializer for Genres"""

    class Meta:
        """Model and field definitions"""

        model = models.Genre
        fields = ("name",)


class GameAliasSerializer(serializers.ModelSerializer):
    """Serializer for game aliases, used to provide an alias list to GameSerializer"""

    class Meta:
        """Model and field definitions"""

        model = models.GameAlias
        fields = ("slug", "name")


class MicroGameSerializer(serializers.ModelSerializer):
    """Another Serializer for Games since DRF doesn't support recursive relationships.
    Also can be used for very small reference to games"""

    class Meta:
        """Model and field definitions"""

        model = models.Game
        fields = ("id", "slug", "name")


class ShaderCacheSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.ShaderCache
        fields = ("url", "updated_at")


class InstallerSerializer(serializers.ModelSerializer):
    """Serializer for Installers"""

    script = serializers.ReadOnlyField(source="raw_script")
    game_id = serializers.PrimaryKeyRelatedField(read_only=True)
    game_slug = serializers.ReadOnlyField(source="game.slug")
    name = serializers.ReadOnlyField(source="game.name")
    year = serializers.ReadOnlyField(source="game.year")
    steamid = serializers.ReadOnlyField(source="game.steamid")
    gogid = serializers.ReadOnlyField(source="game.gogid")
    gogslug = serializers.ReadOnlyField(source="game.gogslug")
    humbleid = serializers.ReadOnlyField(source="game.humbleid")
    humblestoreid = serializers.ReadOnlyField(source="game.humbleid")
    humblestoreid_real = serializers.ReadOnlyField(source="game.humblestoreid")
    # Adding Discord ID for Rich Presence Client
    discord_id = serializers.ReadOnlyField(source="game.discord_id", allow_null=True)

    user = serializers.StringRelatedField()

    runner = serializers.SlugRelatedField(slug_field="slug", read_only=True)

    class Meta:
        """Model and field definitions"""

        model = models.Installer
        fields = (
            "id",
            "game_id",
            "game_slug",
            "name",
            "year",
            "user",
            "runner",
            "slug",
            "version",
            "description",
            "notes",
            "credits",
            "created_at",
            "updated_at",
            "draft",
            "published",
            "published_by",
            "rating",
            "is_playable",
            "steamid",
            "gogid",
            "gogslug",
            "humbleid",
            "humblestoreid",
            "humblestoreid_real",
            "script",
            "content",
            "discord_id",
        )


class InstallerHistorySerializer(serializers.ModelSerializer):
    """Serializer for Installers History"""

    runnername = serializers.ReadOnlyField(source="runner.name")
    user = serializers.StringRelatedField()

    class Meta:
        """Model and field definitions"""

        model = models.InstallerHistory
        fields = (
            "id",
            "version",
            "description",
            "notes",
            "content",
            "created_at",
            "installer_id",
            "runnername",
            "user",
        )


class InstallerDraftSerializer(serializers.ModelSerializer):
    """Serializer for Installers"""

    script = serializers.ReadOnlyField(source="raw_script")
    game = MicroGameSerializer()
    game_slug = serializers.ReadOnlyField(source="game.slug")
    name = serializers.ReadOnlyField(source="game.name")
    year = serializers.ReadOnlyField(source="game.year")
    steamid = serializers.ReadOnlyField(source="game.steamid")
    gogid = serializers.ReadOnlyField(source="game.gogid")
    gogslug = serializers.ReadOnlyField(source="game.gogslug")
    humbleid = serializers.ReadOnlyField(source="game.humbleid")
    humblestoreid = serializers.ReadOnlyField(source="game.humbleid")
    humblestoreid_real = serializers.ReadOnlyField(source="game.humblestoreid")
    # Adding Discord ID for Rich Presence Client
    discord_id = serializers.ReadOnlyField(source="game.discord_id", allow_null=True)

    user = serializers.StringRelatedField()

    runner = serializers.SlugRelatedField(slug_field="slug", read_only=True)
    base_installer = InstallerSerializer()

    class Meta:
        """Model and field definitions"""

        model = models.InstallerDraft
        fields = (
            "id",
            "game",
            "game_slug",
            "name",
            "year",
            "user",
            "runner",
            "slug",
            "version",
            "description",
            "notes",
            "credits",
            "created_at",
            "draft",
            "steamid",
            "gogid",
            "gogslug",
            "humbleid",
            "humblestoreid",
            "humblestoreid_real",
            "script",
            "content",
            "discord_id",
            "base_installer",
            "review",
            "reason",
        )


class InstallerDraftWriteSerializer(serializers.ModelSerializer):
    """Serializer for creating/updating installer drafts via API"""

    game_slug = serializers.SlugField(write_only=True)
    runner = serializers.SlugRelatedField(slug_field="slug", queryset=Runner.objects.all())
    # Optional: link to existing installer for edits
    base_installer_id = serializers.IntegerField(write_only=True, required=False, allow_null=True)
    # draft=True means save as draft, draft=False means submit for moderation
    draft = serializers.BooleanField(default=False)

    class Meta:
        """Model and field definitions"""

        model = models.InstallerDraft
        fields = (
            "id",
            "game_slug",
            "runner",
            "version",
            "description",
            "notes",
            "credits",
            "content",
            "draft",
            "reason",
            "base_installer_id",
        )
        read_only_fields = ("id",)

    def validate_game_slug(self, value):
        """Validate game exists"""
        try:
            models.Game.objects.get(slug=value, change_for__isnull=True)
        except models.Game.DoesNotExist:
            raise serializers.ValidationError(f"Game with slug '{value}' not found")
        return value

    def validate_content(self, value):
        """Validate YAML and strip metadata fields"""
        import yaml

        from common.util import dump_yaml, load_yaml

        try:
            yaml_data = load_yaml(value)
        except yaml.error.MarkedYAMLError as ex:
            raise serializers.ValidationError(
                f"Invalid YAML at line {ex.problem_mark.line}: {ex.problem}"
            )
        if not yaml_data:
            raise serializers.ValidationError("Content cannot be empty")
        # Strip metadata fields that shouldn't be in script
        if "script" in yaml_data:
            yaml_data = yaml_data["script"]
        return dump_yaml(yaml_data)

    def validate(self, attrs):
        """Run full installer validation"""
        from games.util.installer import validate_installer

        game_slug = attrs.get("game_slug")
        game = models.Game.objects.get(slug=game_slug, change_for__isnull=True)

        # Create a dummy installer for validation
        dummy = models.Installer(
            game=game,
            runner=attrs.get("runner"),
            version=attrs.get("version", ""),
            content=attrs.get("content", ""),
        )
        is_valid, errors = validate_installer(dummy)
        if not is_valid:
            raise serializers.ValidationError({"content": errors})

        # Check version uniqueness for new installers
        base_installer_id = attrs.get("base_installer_id")
        version = attrs.get("version")
        if version:
            existing = models.Installer.objects.filter(game=game, version=version)
            if base_installer_id:
                existing = existing.exclude(id=base_installer_id)
            if existing.exists():
                raise serializers.ValidationError(
                    {"version": "An installer with this version already exists for this game"}
                )

        return attrs

    def create(self, validated_data):
        """Create installer draft"""
        from django.utils import timezone

        game_slug = validated_data.pop("game_slug")
        base_installer_id = validated_data.pop("base_installer_id", None)

        game = models.Game.objects.get(slug=game_slug, change_for__isnull=True)
        user = self.context["request"].user

        base_installer = None
        if base_installer_id:
            try:
                base_installer = models.Installer.objects.get(id=base_installer_id)
            except models.Installer.DoesNotExist:
                pass

        draft = models.InstallerDraft.objects.create(
            game=game,
            user=user,
            base_installer=base_installer,
            created_at=timezone.now(),
            **validated_data,
        )
        return draft


class GameSerializer(serializers.ModelSerializer):
    """Serializer for Games"""

    provider_games = ProviderGameSerializer(many=True)
    platforms = PlatformSerializer(many=True)
    aliases = GameAliasSerializer(many=True)
    shaders = ShaderCacheSerializer(many=True)
    change_for = MicroGameSerializer()

    class Meta:
        """Model and field definitions"""

        model = models.Game
        fields = (
            "id",
            "name",
            "slug",
            "year",
            "banner_url",
            "icon_url",
            "coverart",
            "platforms",
            "provider_games",
            "aliases",
            "shaders",
            "discord_id",
            "change_for",
        )


class SubmittedGameSerializer(GameSerializer):
    """Game as shown in the moderation queue.

    Adds the fields a moderator needs to judge a submission (the website is what
    link spam is usually after) without widening the game API the client uses.
    """

    class Meta(GameSerializer.Meta):
        """Model and field definitions"""

        fields = GameSerializer.Meta.fields + ("website", "description")


class GameSubmissionSerializer(serializers.ModelSerializer):
    """Serializer for game submissions"""

    game = SubmittedGameSerializer()
    user = UserSerializer()
    spam_assessment = serializers.SerializerMethodField()
    library_game_count = serializers.SerializerMethodField()

    class Meta:
        """Model and field definitions"""

        model = models.GameSubmission
        fields = (
            "id",
            "user",
            "game",
            "created_at",
            "accepted_at",
            "reason",
            "ip_address",
            "spam_assessment",
            "library_game_count",
        )

    def get_library_game_count(self, submission):
        """How many games the submitter has in their library, None if not annotated"""
        return getattr(submission, "library_game_count", None)

    def get_spam_assessment(self, submission):
        """Advisory spam score shown to moderators, None when unavailable"""
        return antispam.assess_submission(
            submission, getattr(submission, "library_game_count", None)
        )


class GameMergeSuggestionSerializer(serializers.ModelSerializer):
    """Serializer for game merge suggestions"""

    game = GameSerializer()
    other_game = GameSerializer()
    user = UserSerializer()

    class Meta:
        """Model and field definitions"""

        model = models.GameMergeSuggestion
        fields = (
            "id",
            "user",
            "game",
            "other_game",
            "created_at",
            "accepted_at",
            "reason",
        )


class GameDetailSerializer(GameSerializer):
    """A serializer for games with it's associated meta-data.
    Do not use in List views as it might cause performance issues.
    """

    genres = GenreSerializer(many=True)
    platforms = PlatformSerializer(many=True)
    aliases = GameAliasSerializer(many=True)
    installers = InstallerSerializer(many=True)
    shaders = ShaderCacheSerializer(many=True)

    class Meta:
        """Model and field definitions"""

        model = models.Game
        fields = (
            "name",
            "slug",
            "year",
            "platforms",
            "genres",
            "aliases",
            "description",
            "banner_url",
            "icon_url",
            "coverart",
            "is_public",
            "updated",
            "steamid",
            "gogslug",
            "humblestoreid",
            "id",
            "user_count",
            "installers",
            "shaders",
            "discord_id",
        )


class TransitonalLibrarySerializer(serializers.ModelSerializer):
    name = serializers.ReadOnlyField(source="game.name")
    slug = serializers.ReadOnlyField(source="game.slug")
    banner_url = serializers.ReadOnlyField(source="banner")
    icon_url = serializers.ReadOnlyField(source="icon")

    class Meta:
        model = models.LibraryGame
        fields = (
            "name",
            "slug",
            "banner_url",
            "coverart",
            "icon_url",
        )


class GameLibrarySerializer(serializers.ModelSerializer):
    """Serializer for Games"""

    games = TransitonalLibrarySerializer(many=True)

    class Meta:
        """Model and field definitions"""

        model = models.GameLibrary
        fields = ("user", "games")


class GameInstallersSerializer(GameSerializer):
    """Serializer for Installers belonging to a specific game"""

    installers = InstallerSerializer(many=True)

    class Meta:
        """Model and field definitions"""

        model = models.Game
        fields = (
            "id",
            "name",
            "slug",
            "year",
            "platforms",
            "genres",
            "banner_url",
            "icon_url",
            "is_public",
            "updated",
            "steamid",
            "gogid",
            "gogslug",
            "humblestoreid",
            "installers",
        )


class InstallerIssueReplySerializer(serializers.ModelSerializer):
    """Serializer for Installer issues"""

    username = serializers.SerializerMethodField()

    class Meta:
        """Model and field definitions"""

        model = models.InstallerIssueReply
        fields = ("id", "issue", "username", "submitted_by", "submitted_on", "description")

    def get_username(self, obj):  # pylint: disable=no-self-use
        """Return the username from the submitted_by field"""
        return obj.submitted_by.username


class InstallerIssueSerializer(serializers.ModelSerializer):
    """Serializer for installer issues"""

    replies = InstallerIssueReplySerializer(many=True, required=False)
    username = serializers.SerializerMethodField()

    class Meta:
        """Model and field definitions"""

        model = models.InstallerIssue
        fields = (
            "id",
            "installer",
            "username",
            "submitted_by",
            "submitted_on",
            "description",
            "solved",
            "replies",
        )

    def get_username(self, obj):  # pylint: disable=no-self-use
        """Return the username from the submitted_by field"""
        return obj.submitted_by.username


class InstallerIssueListSerializer(serializers.ModelSerializer):
    """Serializer for grouping all issues from a installer together"""

    issues = InstallerIssueSerializer(many=True)

    class Meta:
        """Model and field definitions"""

        model = models.Installer
        fields = (
            "id",
            "slug",
            "version",
            "issues",
        )


class GameRelatedField(serializers.RelatedField):
    """A custom field to load games from generic relationship"""

    def to_representation(self, value):
        """
        Serialize tagged objects to a simple textual representation.
        """
        if isinstance(value, models.Installer):
            serializer = InstallerSerializer(value)
            return serializer.data
        raise Exception("Unexpected type of tagged object")

    def to_internal_value(self, _value):
        """Raise an exception when trying to change back to internal values"""
        raise Exception("This field is read-only")


class RegressionSerializer(serializers.ModelSerializer):
    """Read serializer for regressions"""

    games = MicroGameSerializer(many=True, read_only=True)
    submitted_by = serializers.StringRelatedField()
    reviewed_by = serializers.StringRelatedField()

    class Meta:
        model = models.Regression
        fields = (
            "id",
            "title",
            "description",
            "bug_url",
            "bug_status",
            "last_known_working_version",
            "games",
            "status",
            "submitted_by",
            "reviewed_by",
            "created_at",
            "updated_at",
            "resolved_at",
        )


class RegressionWriteSerializer(serializers.ModelSerializer):
    """Write serializer for regression submissions"""

    game_slugs = serializers.ListField(child=serializers.SlugField(), write_only=True)

    class Meta:
        model = models.Regression
        fields = (
            "id",
            "title",
            "description",
            "bug_url",
            "last_known_working_version",
            "game_slugs",
        )
        read_only_fields = ("id",)

    def validate_game_slugs(self, value):
        if not value:
            raise serializers.ValidationError("At least one game slug is required.")
        games = models.Game.objects.filter(slug__in=value, change_for__isnull=True)
        found_slugs = set(games.values_list("slug", flat=True))
        missing = set(value) - found_slugs
        if missing:
            raise serializers.ValidationError(f"Games not found: {', '.join(missing)}")
        return value

    def create(self, validated_data):
        game_slugs = validated_data.pop("game_slugs")
        user = self.context["request"].user
        regression = models.Regression.objects.create(submitted_by=user, **validated_data)
        games = models.Game.objects.filter(slug__in=game_slugs, change_for__isnull=True)
        regression.games.set(games)
        return regression


class ScreenshotSerializer(serializers.ModelSerializer):
    """Serializer for Screenshots"""

    game = MicroGameSerializer()
    uploaded_by = UserSerializer()

    class Meta:
        """Model and field definitions"""

        model = models.Screenshot
        fields = ("id", "game", "image", "uploaded_at", "uploaded_by", "description", "published")
