"""Email utility functions"""

import socket

from django.conf import settings
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from premailer import transform
from six import string_types


def send_game_accepted(user, game):
    """Email an user when their game submission is accepted"""
    context = {"username": user.username, "name": game.name, "game_url": game.get_absolute_url()}
    subject = f"Your game submission for '{game.name}' has been accepted!"
    return send_email("game_accepted", context, subject, user.email)


def send_account_creation(user, confirmation_link):
    """Email users on account creation"""
    context = {"username": user.username, "confirmation_link": confirmation_link}
    subject = "Welcome to Lutris.net"
    return send_email("account_creation", context, subject, user.email)


def send_account_banned(username, email, game_name):
    """Tell a user their account was closed for a spam submission.

    Takes the name and address explicitly: by the time this is sent the account
    has been deactivated, which blanks both.
    """
    context = {"username": username, "game_name": game_name}
    subject = "Your Lutris account has been closed"
    return send_email("account_banned", context, subject, email)


def send_email(template, context, subject, recipients, sender=None):
    """Send an email using a HTML template"""
    if not settings.SEND_EMAILS:
        return
    context.update(
        {
            "STATIC_URL": settings.STATIC_URL,
            "MEDIA_URL": settings.MEDIA_URL,
        }
    )
    sender = sender or settings.DEFAULT_FROM_EMAIL
    if isinstance(recipients, string_types):
        recipients = [recipients]
    # A deactivated account has no address, and Django raises ValueError from
    # inside the SMTP backend rather than failing quietly on an empty one.
    recipients = [recipient for recipient in recipients if recipient]
    if not recipients:
        return 0
    subject = f"{settings.EMAIL_SUBJECT_PREFIX} {subject}"
    text_part = render_to_string(f"emails/{template}.txt", context)
    msg = EmailMultiAlternatives(subject=subject, body=text_part, to=recipients, from_email=sender)
    html_body = render_to_string(f"emails/{template}.html", context)
    # Premailer does not handle https links, the site can't access itself
    # with HTTPS inside its container.
    # Under no circumstances this should be switched to https.
    html_part = transform(html_body, base_url="http://lutris.net")
    msg.attach_alternative(html_part, "text/html")
    try:
        return msg.send(False)
    except socket.gaierror:
        return 0


def notify_rejected_installer(installer, review, user):
    """Notify a user their installer was rejected"""
    context = {"username": user.username, "installer": installer, "review": review}
    subject = f"Your installer for {installer} wasn't published"
    send_email("installer_rejected", context, subject, user.email)
